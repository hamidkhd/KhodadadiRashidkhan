// bbp-widgets.js
// "Adapter-like" utilities to match DD: Map Adapter + Weather Adapter + Notification-like UI.

function initMap(mapId, center = [45.4642, 9.19], zoom = 13) {
  const map = L.map(mapId, { zoomControl: true }).setView(center, zoom);

  L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(map);

  return map;
}

function addDemoRoute(map, points) {
  const poly = L.polyline(points, { weight: 5, opacity: 0.85 }).addTo(map);
  map.fitBounds(poly.getBounds(), { padding: [20, 20] });

  L.marker(points[0]).addTo(map).bindPopup("Origin");
  L.marker(points[points.length - 1]).addTo(map).bindPopup("Destination");
  return poly;
}

function getUserLocation() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) return reject(new Error("Geolocation not supported"));
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve([pos.coords.latitude, pos.coords.longitude]),
      (err) => reject(err),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  });
}

// Weather Adapter (OpenWeather current)
async function loadCurrentWeather(lat, lon, targetId, statusId, apiKey) {
  const statusEl = document.getElementById(statusId);
  const targetEl = document.getElementById(targetId);

  if (!apiKey || apiKey === "YOUR_OPENWEATHER_KEY") {
    statusEl.textContent = "No API key";
    targetEl.innerHTML = `<div class="small-muted">
      Add your OpenWeather API key in the page script to enable weather.
    </div>`;
    return;
  }

  try {
    statusEl.textContent = "Loading…";
    const url =
      `https://api.openweathermap.org/data/2.5/weather?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&units=metric&appid=${encodeURIComponent(apiKey)}`;

    const res = await fetch(url);
    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Weather HTTP ${res.status}: ${errText}`);
    }
    const data = await res.json();

    const name = data.name ?? "Your area";
    const temp = Math.round(data.main?.temp ?? NaN);
    const desc = data.weather?.[0]?.description ?? "—";
    const wind = data.wind?.speed ?? "—";

    statusEl.textContent = "Updated";
    targetEl.innerHTML = `
      <div class="d-flex justify-content-between">
        <div>
          <div class="fw-semibold">${name}</div>
          <div class="small-muted text-capitalize">${desc}</div>
        </div>
        <div class="text-end">
          <div class="fw-semibold">${Number.isFinite(temp) ? temp + "°C" : "—"}</div>
          <div class="small-muted">Wind: ${wind} m/s</div>
        </div>
      </div>
    `;
  } catch (e) {
    statusEl.textContent = "Unavailable";
    targetEl.innerHTML = `<div class="small-muted">Weather unavailable (${e.message}).</div>`;
  }
}

// UI Notification helper (Bootstrap toast)
function showToast(message, title = "BBP", tone = "primary") {
  const containerId = "bbpToastContainer";
  let container = document.getElementById(containerId);

  if (!container) {
    container = document.createElement("div");
    container.id = containerId;
    container.className = "toast-container position-fixed top-0 end-0 p-3";
    container.style.zIndex = "1080";
    document.body.appendChild(container);
  }

  const toastEl = document.createElement("div");
  toastEl.className = "toast align-items-center text-bg-" + tone + " border-0";
  toastEl.setAttribute("role", "alert");
  toastEl.setAttribute("aria-live", "assertive");
  toastEl.setAttribute("aria-atomic", "true");

  toastEl.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">
        <div class="fw-semibold">${title}</div>
        <div>${message}</div>
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>
  `;

  container.appendChild(toastEl);
  const toast = new bootstrap.Toast(toastEl, { delay: 2500 });
  toast.show();

  toastEl.addEventListener("hidden.bs.toast", () => toastEl.remove());
}

// Offline indicator helper
function isOnline() {
  return navigator.onLine;
}
