// bbp-api.js
// Frontend API client that mirrors the API Gateway role in the DD.
// For now it runs in MOCK mode so your static HTML works without a backend.
// When you have a backend, set MOCK_MODE=false and set API_BASE.

const BBP = (() => {
  const MOCK_MODE = true;
  const API_BASE = "/api"; // change to "https://your-domain/api" later

  const TOKEN_KEY = "bbp_token";
  const USER_KEY = "bbp_user";

  function getToken() {
    return localStorage.getItem(TOKEN_KEY);
  }
  function setToken(token) {
    localStorage.setItem(TOKEN_KEY, token);
  }
  function clearToken() {
    localStorage.removeItem(TOKEN_KEY);
  }

  function getUser() {
    const raw = localStorage.getItem(USER_KEY);
    return raw ? JSON.parse(raw) : null;
  }
  function setUser(user) {
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  }
  function clearUser() {
    localStorage.removeItem(USER_KEY);
  }

  async function request(path, { method = "GET", body = null, auth = true } = {}) {
    if (MOCK_MODE) return mockRequest(path, { method, body, auth });

    const headers = { "Content-Type": "application/json" };
    if (auth) {
      const token = getToken();
      if (token) headers["Authorization"] = `Bearer ${token}`;
    }

    const res = await fetch(`${API_BASE}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : null
    });

    const text = await res.text();
    const data = text ? JSON.parse(text) : null;
    if (!res.ok) throw new Error(data?.message || `HTTP ${res.status}`);
    return data;
  }

  // ---------------- MOCK IMPLEMENTATION ----------------
  function mockDelay(ms = 300) {
    return new Promise(r => setTimeout(r, ms));
  }

  function mockDb() {
    const key = "bbp_mock_db";
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw);

    // Seed demo data (kept in localStorage so actions persist across reloads)
    const initial = {
      profile: {
        displayName: "Registered Cyclist",
        email: "account@example.com",
        privacy: {
          sharePublishable: true,
          allowLocation: true,
          saveHistory: true,
          weatherEnrichment: true
        }
      },
      trips: [
        { id: "t1", name: "", dateLabel: "Today", distanceKm: 6.4, minutes: 22, avgSpeed: 17.4 },
        { id: "t2", name: "", dateLabel: "Yesterday", distanceKm: 9.1, minutes: 35, avgSpeed: 15.6 }
      ],
      paths: [
        { id: "p1", name: "Path 1", distanceKm: 7.2, status: "Optimal", publishable: true },
        { id: "p2", name: "Path 2", distanceKm: 6.1, status: "Medium", publishable: false }
      ],
      issues: [
        { id: "i1", title: "Possible pothole", where: "Via Torino", signal: "Detected from vibrations", state: "pending" },
        { id: "i2", title: "Possible roadworks", where: "Viale Zara", signal: "Sudden slowdown", state: "pending" }
      ]
    };

    localStorage.setItem(key, JSON.stringify(initial));
    return initial;
  }

  function saveMockDb(db) {
    localStorage.setItem("bbp_mock_db", JSON.stringify(db));
  }

  function resetMockIssues(db) {
    db.issues = [
      { id: "i1", title: "Possible pothole", where: "Via Torino", signal: "Detected from vibrations", state: "pending" },
      { id: "i2", title: "Possible roadworks", where: "Viale Zara", signal: "Sudden slowdown", state: "pending" }
    ];
  }

  async function mockRequest(path, { method, body, auth }) {
    await mockDelay();

    // ---- Admin-ish health endpoint (demo) ----
    if (path === "/health" && method === "GET") {
      return {
        apiGateway: "online",
        database: "online",
        externalMap: "reachable",
        externalWeather: "optional"
      };
    }

    // ---- Auth simulation ----
    if (path === "/auth/login" && method === "POST") {
      setToken("mock-token-123");
      setUser({ email: body?.email || "account@example.com", role: "cyclist" });
      return { token: "mock-token-123" };
    }
    if (path === "/auth/logout" && method === "POST") {
      clearToken();
      clearUser();
      return { ok: true };
    }

    if (auth && !getToken()) {
      throw new Error("Unauthorized (mock): missing token");
    }

    const db = mockDb();

    // ---- Profile (User Profile Service) ----
    if (path === "/profile" && method === "GET") return db.profile;
    if (path === "/profile" && method === "PUT") {
      db.profile = { ...db.profile, ...body };
      saveMockDb(db);
      return db.profile;
    }

    // ---- Trips (Trip Service) ----
    if (path === "/trips" && method === "GET") return db.trips;
    if (path === "/trips/upload" && method === "POST") {
      db.trips.unshift({
        id: `t${Date.now()}`,
        name: body?.name ?? "",
        dateLabel: "Just now",
        distanceKm: body?.distanceKm ?? 2.4,
        minutes: body?.minutes ?? 12,
        avgSpeed: body?.avgSpeed ?? 11.7
      });
      saveMockDb(db);
      return { ok: true };
    }

    // ---- Issues (Issue Detection + Issue Review Services) ----
    // List all issues (useful for admin/history pages)
    if (path === "/issues" && method === "GET") return db.issues;

    // Pending only
    if (path === "/issues/pending" && method === "GET") {
      return db.issues.filter(i => i.state === "pending");
    }

    // Reset demo issues (for testing)
    if (path === "/issues/reset" && method === "POST") {
      resetMockIssues(db);
      saveMockDb(db);
      return { ok: true };
    }

    // Review action (confirm/correct/reject)
    if (path.startsWith("/issues/") && method === "POST") {
      const id = path.split("/")[2];
      const issue = db.issues.find(i => i.id === id);
      if (!issue) throw new Error("Issue not found");

      const action = body?.action;
      const allowed = ["confirm", "correct", "reject"];
      if (!allowed.includes(action)) throw new Error(`Invalid action. Allowed: ${allowed.join(", ")}`);

      issue.state = action; // state becomes confirm/correct/reject (no longer pending)
      saveMockDb(db);
      return { ok: true };
    }

    // ---- Route query (Route Query Service) ----
    if (path === "/route-query" && method === "POST") {
      const pref = (body?.preference || "Balanced").toLowerCase();

      // Slight variation by preference (UI demo only)
      if (pref.includes("saf")) {
        return [
          { id: "c1", name: "Candidate Path 1", score: 94, distanceKm: 7.4, note: "Lowest obstacles" },
          { id: "c2", name: "Candidate Path 2", score: 86, distanceKm: 8.0, note: "Good surfaces" },
          { id: "c3", name: "Candidate Path 3", score: 78, distanceKm: 6.1, note: "More traffic" }
        ];
      }
      if (pref.includes("fast")) {
        return [
          { id: "c1", name: "Candidate Path 1", score: 90, distanceKm: 6.1, note: "Shortest ETA" },
          { id: "c2", name: "Candidate Path 2", score: 85, distanceKm: 7.2, note: "Safer option" },
          { id: "c3", name: "Candidate Path 3", score: 80, distanceKm: 8.0, note: "Longer but smooth" }
        ];
      }
      if (pref.includes("comfort")) {
        return [
          { id: "c1", name: "Candidate Path 1", score: 92, distanceKm: 8.0, note: "Best surface" },
          { id: "c2", name: "Candidate Path 2", score: 88, distanceKm: 7.2, note: "Few obstacles" },
          { id: "c3", name: "Candidate Path 3", score: 79, distanceKm: 6.1, note: "Rough segments" }
        ];
      }

      // Balanced default
      return [
        { id: "c1", name: "Candidate Path 1", score: 92, distanceKm: 7.2, note: "Low obstacles" },
        { id: "c2", name: "Candidate Path 2", score: 84, distanceKm: 6.1, note: "Medium traffic" },
        { id: "c3", name: "Candidate Path 3", score: 78, distanceKm: 8.0, note: "Best surface" }
      ];
    }

    // ---- Paths (Path Service) ----
    if (path === "/paths" && method === "GET") return db.paths;
    if (path === "/paths" && method === "POST") {
      db.paths.unshift({
        id: `p${Date.now()}`,
        name: body?.name || "New path",
        distanceKm: body?.distanceKm ?? 7.0,
        status: body?.status || "Medium",
        publishable: !!body?.publishable
      });
      saveMockDb(db);
      return { ok: true };
    }

    throw new Error(`Mock route not implemented: ${method} ${path}`);
  }

  // ---- Public API (client-side gateway) ----
  return {
    request,

    auth: {
      login: (email, password) =>
        request("/auth/login", { method: "POST", body: { email, password }, auth: false }),
      logout: () => request("/auth/logout", { method: "POST" }),
      token: getToken,
      user: getUser
    },

    profile: {
      get: () => request("/profile"),
      update: (payload) => request("/profile", { method: "PUT", body: payload })
    },

    trips: {
      list: () => request("/trips"),
      upload: (payload) => request("/trips/upload", { method: "POST", body: payload })
    },

    issues: {
      list: () => request("/issues"),
      pending: () => request("/issues/pending"),
      reset: () => request("/issues/reset", { method: "POST" }),
      action: (id, action, payload = {}) =>
        request(`/issues/${id}`, { method: "POST", body: { action, ...payload } })
    },

    routes: {
      query: (origin, destination, preference) =>
        request("/route-query", { method: "POST", body: { origin, destination, preference } })
    },

    paths: {
      list: () => request("/paths"),
      create: (payload) => request("/paths", { method: "POST", body: payload })
    },

    admin: {
      health: () => request("/health")
    }
  };
})();
